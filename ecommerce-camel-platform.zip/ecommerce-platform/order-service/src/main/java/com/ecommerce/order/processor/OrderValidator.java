package com.ecommerce.order.processor;

import com.ecommerce.order.model.OrderRequest;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

@Component
public class OrderValidator implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {
        OrderRequest order = exchange.getIn().getBody(OrderRequest.class);

        if (order == null) {
            throw new IllegalArgumentException("Order body is required");
        }
        if (order.getCustomerId() == null || order.getCustomerId().isBlank()) {
            throw new IllegalArgumentException("Customer ID is required");
        }
        if (order.getProductId() == null || order.getProductId().isBlank()) {
            throw new IllegalArgumentException("Product ID is required");
        }
        if (order.getQuantity() <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than zero");
        }
        if (order.getTotalAmount() <= 0) {
            throw new IllegalArgumentException("Total amount must be positive");
        }

        // Set defaults
        order.setStatus("PENDING");
        exchange.getIn().setBody(order);
    }
}
