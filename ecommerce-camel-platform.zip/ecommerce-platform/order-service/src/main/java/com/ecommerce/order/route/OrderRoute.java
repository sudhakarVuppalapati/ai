package com.ecommerce.order.route;

import com.ecommerce.order.config.OrderService;
import com.ecommerce.order.model.OrderRequest;
import com.ecommerce.order.model.PaymentEvent;
import com.ecommerce.order.processor.OrderEnricher;
import com.ecommerce.order.processor.OrderValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class OrderRoute extends RouteBuilder {

    private final OrderValidator orderValidator;
    private final OrderEnricher orderEnricher;
    private final OrderService orderService;

    @Override
    public void configure() {

        // Global error: validation
        onException(IllegalArgumentException.class)
            .handled(true)
            .setHeader("CamelHttpResponseCode", constant(400))
            .setBody(simple("{\"error\": \"${exception.message}\", \"status\": 400}"))
            .log("Validation error: ${exception.message}");

        // Global error: unexpected
        onException(Exception.class)
            .maximumRedeliveries(3)
            .redeliveryDelay(2000)
            .backOffMultiplier(2)
            .useExponentialBackOff()
            .handled(true)
            .log("Order processing failed: ${exception.message}")
            .setHeader("CamelHttpResponseCode", constant(500))
            .setBody(simple("{\"error\": \"Internal error\", \"status\": 500}"));

        // Route 1: POST /orders - create new order
        from("servlet:/orders?httpMethodRestrict=POST")
            .routeId("receive-order")
            .log("New order received")
            .unmarshal().json(JsonLibrary.Jackson, OrderRequest.class)
            .process(orderValidator)
            .process(orderEnricher)
            .process(exchange -> {
                OrderRequest order = exchange.getIn().getBody(OrderRequest.class);
                OrderRequest saved = orderService.save(order);
                exchange.getIn().setBody(saved);
            })
            .marshal().json(JsonLibrary.Jackson)
            .to("kafka:order.created?brokers={{kafka.brokers}}")
            .log("Order published to Kafka: ${body}")
            .setHeader("CamelHttpResponseCode", constant(201))
            .setHeader("Content-Type", constant("application/json"))
            .setBody(simple("{\"message\": \"Order created successfully\", \"status\": \"PENDING\"}"));

        // Route 2: Consume payment result from Kafka
        from("kafka:payment.processed?brokers={{kafka.brokers}}&groupId=order-service&autoOffsetReset=earliest")
            .routeId("handle-payment-result")
            .log("Payment event received: ${body}")
            .unmarshal().json(JsonLibrary.Jackson, PaymentEvent.class)
            .process(exchange -> {
                PaymentEvent event = exchange.getIn().getBody(PaymentEvent.class);
                String newStatus = event.isSuccess() ? "CONFIRMED" : "PAYMENT_FAILED";
                orderService.updateStatus(event.getOrderId(), newStatus);
                exchange.getIn().setHeader("orderId", event.getOrderId());
                exchange.getIn().setHeader("newStatus", newStatus);
            })
            .log("Order ${header.orderId} updated to ${header.newStatus}");

        // Route 3: Health check
        from("servlet:/health")
            .routeId("order-health")
            .setHeader("Content-Type", constant("application/json"))
            .setBody(constant("{\"service\": \"order-service\", \"status\": \"UP\"}"));
    }
}
