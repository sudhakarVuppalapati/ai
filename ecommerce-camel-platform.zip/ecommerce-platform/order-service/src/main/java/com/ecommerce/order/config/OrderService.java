package com.ecommerce.order.config;

import com.ecommerce.order.model.OrderRequest;
import com.ecommerce.order.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;

    public OrderRequest save(OrderRequest order) {
        log.info("Saving order: {}", order.getOrderId());
        return orderRepository.save(order);
    }

    public void updateStatus(String orderId, String status) {
        orderRepository.findByOrderId(orderId).ifPresent(order -> {
            order.setStatus(status);
            order.setUpdatedAt(LocalDateTime.now());
            orderRepository.save(order);
            log.info("Order {} updated to status: {}", orderId, status);
        });
    }
}
