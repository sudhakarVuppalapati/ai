package com.ecommerce.order.repository;

import com.ecommerce.order.model.OrderRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OrderRepository extends JpaRepository<OrderRequest, Long> {
    Optional<OrderRequest> findByOrderId(String orderId);
}
