package com.ecommerce.order.processor;

import com.ecommerce.order.model.OrderRequest;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class OrderEnricher implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {
        OrderRequest order = exchange.getIn().getBody(OrderRequest.class);

        // Generate unique order ID
        order.setOrderId("ORD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());

        // Resolve region from customer ID prefix
        if (order.getCustomerId() != null) {
            String prefix = order.getCustomerId().substring(0, 2).toUpperCase();
            String region = switch (prefix) {
                case "US" -> "NORTH_AMERICA";
                case "EU" -> "EUROPE";
                case "AP" -> "ASIA_PACIFIC";
                default -> "GLOBAL";
            };
            order.setRegion(region);
        }

        exchange.getIn().setBody(order);
    }
}
