# E-Commerce Platform — Apache Camel + Spring Boot

Apache Camel acts as the **nervous system** connecting all microservices.
Each service handles its own business logic. Camel handles everything in between:
routing, transformation, retries, circuit breakers, and fan-out notifications.

---

## Architecture

```
Client
  │
  ▼
API Gateway (port 8080 - optional, use nginx or Spring Cloud Gateway)
  │
  ▼
┌─────────────────────────────────────────┐
│     Apache Camel Integration Layer      │
│  Route · Transform · Retry · Circuit    │
└─────────────────────────────────────────┘
  │           │           │           │
  ▼           ▼           ▼           ▼
Order(8081) Inventory(8082) Payment(8083) Notification(8084)
  │           │           │           │
  └───────────┴───────────┴───────────┘
                    │
                    ▼
             Kafka Event Bus
         order.created | inventory.reserved
         payment.processed | inventory.unavailable
```

---

## Prerequisites

Install these before starting:

| Tool        | Version  | Download                          |
|-------------|----------|-----------------------------------|
| Java JDK    | 17+      | https://adoptium.net              |
| Maven       | 3.8+     | https://maven.apache.org          |
| Docker      | 24+      | https://www.docker.com            |
| Docker Compose | 2.0+  | Included with Docker Desktop      |

Verify your installation:
```bash
java -version
mvn -version
docker -version
docker compose version
```

---

## Step 1 — Start Kafka with Docker

Open a terminal and run:

```bash
cd docker
docker compose up -d
```

Wait about 20 seconds for Kafka to be ready.

Verify Kafka is running:
```bash
docker compose ps
```

You should see both `zookeeper` and `kafka` with status `Up`.

Open Kafka UI in your browser: http://localhost:8080
You will see the Kafka cluster. Topics will appear automatically when services start.

---

## Step 2 — Build All Services

From the root of the project:

```bash
mvn clean install -DskipTests
```

This compiles all four services. Takes about 2-3 minutes on first run
while Maven downloads dependencies.

---

## Step 3 — Start Services (4 Terminals)

Open four separate terminal windows. Start each service in its own terminal:

**Terminal 1 — Order Service (port 8081)**
```bash
cd order-service
mvn spring-boot:run
```

Wait until you see: `Started OrderServiceApplication`

**Terminal 2 — Inventory Service (port 8082)**
```bash
cd inventory-service
mvn spring-boot:run
```

Wait until you see: `Started InventoryServiceApplication`

**Terminal 3 — Payment Service (port 8083)**
```bash
cd payment-service
mvn spring-boot:run
```

Wait until you see: `Started PaymentServiceApplication`

**Terminal 4 — Notification Service (port 8084)**
```bash
cd notification-service
mvn spring-boot:run
```

Wait until you see: `Started NotificationServiceApplication`

---

## Step 4 — Verify All Services Are Up

Check health endpoints:

```bash
curl http://localhost:8081/camel/health
curl http://localhost:8082/camel/health
curl http://localhost:8083/camel/health
curl http://localhost:8084/camel/health
```

Each should return:
```json
{"service": "order-service", "status": "UP"}
```

---

## Step 5 — Place Your First Order

Open a new terminal and run:

```bash
curl -X POST http://localhost:8081/camel/orders \
  -H "Content-Type: application/json" \
  -d '{
    "customerId": "US-CUST-001",
    "productId": "PROD-001",
    "quantity": 2,
    "totalAmount": 2999.99
  }'
```

Expected response:
```json
{
  "message": "Order created successfully",
  "status": "PENDING"
}
```

Now watch what happens in each terminal:

- **Order terminal** — logs: "New order received", "Order published to Kafka"
- **Inventory terminal** — logs: "Checking stock", "Stock reserved"
- **Payment terminal** — logs: "Processing payment", "Payment result published"
- **Notification terminal** — logs: "[EMAIL]", "[SMS]", "[PUSH]" all at once
- **Order terminal again** — logs: "Order updated to CONFIRMED"

The entire flow completes in under a second.

---

## Step 6 — Test Different Scenarios

**Test out-of-stock (non-existent product):**
```bash
curl -X POST http://localhost:8081/camel/orders \
  -H "Content-Type: application/json" \
  -d '{
    "customerId": "EU-CUST-002",
    "productId": "PROD-GHOST",
    "quantity": 1,
    "totalAmount": 50.00
  }'
```
Watch inventory terminal log "Out of stock".

**Test payment failure (amount over $10,000):**
```bash
curl -X POST http://localhost:8081/camel/orders \
  -H "Content-Type: application/json" \
  -d '{
    "customerId": "AP-CUST-003",
    "productId": "PROD-002",
    "quantity": 5,
    "totalAmount": 15000.00
  }'
```
Watch payment terminal log "INSUFFICIENT_FUNDS".

**Test validation error (missing fields):**
```bash
curl -X POST http://localhost:8081/camel/orders \
  -H "Content-Type: application/json" \
  -d '{
    "customerId": "US-CUST-004"
  }'
```
Returns 400 with validation message.

---

## Step 7 — View Kafka Topics

Open http://localhost:8080 (Kafka UI).

Go to Topics. You will see:
- `order.created` — every new order
- `inventory.reserved` — stock confirmed orders
- `inventory.unavailable` — out-of-stock orders
- `payment.processed` — payment results
- `payment.failed` — dead letter for failed payments

Click any topic to see the actual messages flowing through.

---

## Step 8 — View H2 Database (Order + Inventory)

**Order Service DB:**
Open http://localhost:8081/h2-console

- JDBC URL: `jdbc:h2:mem:ordersdb`
- Username: `sa`
- Password: (empty)
- Click Connect

Run: `SELECT * FROM ORDERS;`

**Inventory Service DB:**
Open http://localhost:8082/h2-console

- JDBC URL: `jdbc:h2:mem:inventorydb`
- Username: `sa`
- Password: (empty)

Run: `SELECT * FROM INVENTORY;`

---

## Kafka Topics Reference

| Topic                    | Publisher          | Consumers                         |
|--------------------------|--------------------|-----------------------------------|
| order.created            | Order Service      | Inventory Service                 |
| inventory.reserved       | Inventory Service  | Payment Service                   |
| inventory.unavailable    | Inventory Service  | Payment Service                   |
| payment.processed        | Payment Service    | Order Service, Notification Svc   |
| payment.failed           | Payment Service    | (dead letter — monitoring)        |

---

## Service Ports

| Service              | Port | Health URL                          |
|----------------------|------|-------------------------------------|
| Order Service        | 8081 | http://localhost:8081/camel/health  |
| Inventory Service    | 8082 | http://localhost:8082/camel/health  |
| Payment Service      | 8083 | http://localhost:8083/camel/health  |
| Notification Service | 8084 | http://localhost:8084/camel/health  |
| Kafka UI             | 8080 | http://localhost:8080               |

---

## Project Structure

```
ecommerce-platform/
├── pom.xml                          ← parent pom (manages versions)
├── docker/
│   └── docker-compose.yml           ← Kafka + Zookeeper + Kafka UI
├── order-service/
│   ├── pom.xml
│   └── src/main/java/com/ecommerce/order/
│       ├── OrderServiceApplication.java
│       ├── route/OrderRoute.java    ← MAIN: all Camel routes
│       ├── model/OrderRequest.java
│       ├── model/PaymentEvent.java
│       ├── processor/OrderValidator.java
│       ├── processor/OrderEnricher.java
│       ├── repository/OrderRepository.java
│       └── config/OrderService.java
├── inventory-service/
│   └── src/main/java/com/ecommerce/inventory/
│       ├── route/InventoryRoute.java ← checks stock, reserves items
│       ├── model/InventoryItem.java
│       ├── model/OrderEvent.java
│       ├── config/DataLoader.java   ← seeds 4 products on startup
│       └── repository/InventoryRepository.java
├── payment-service/
│   └── src/main/java/com/ecommerce/payment/
│       ├── route/PaymentRoute.java  ← circuit breaker, gateway sim
│       ├── model/OrderEvent.java
│       └── model/PaymentEvent.java
└── notification-service/
    └── src/main/java/com/ecommerce/notification/
        ├── route/NotificationRoute.java ← multicast email+SMS+push
        └── model/PaymentEvent.java
```

---

## Stopping Everything

Stop services: `Ctrl+C` in each terminal.

Stop Kafka:
```bash
cd docker
docker compose down
```

---

## Common Issues

**Port already in use:**
```bash
lsof -i :8081   # find what is using the port
kill -9 <PID>   # stop it
```

**Kafka connection refused:**
Make sure Docker is running and you ran `docker compose up -d` first.
Wait 20 seconds after starting before launching services.

**Build fails:**
```bash
mvn clean install -DskipTests -X   # verbose output for debugging
```

**H2 console not loading:**
The H2 console is only available while the Spring Boot app is running.
It resets on every restart (in-memory database).
