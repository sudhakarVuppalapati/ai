package com.ecommerce.payment.model;
import lombok.Data; import lombok.NoArgsConstructor;
@Data @NoArgsConstructor
public class OrderEvent {
    private String orderId, customerId, productId, region, status;
    private int quantity;
    private double totalAmount;
}
