package com.ecommerce.payment.model;
import lombok.AllArgsConstructor; import lombok.Data; import lombok.NoArgsConstructor;
@Data @NoArgsConstructor @AllArgsConstructor
public class PaymentEvent {
    private String orderId;
    private boolean success;
    private String transactionId;
    private String failureReason;
}
