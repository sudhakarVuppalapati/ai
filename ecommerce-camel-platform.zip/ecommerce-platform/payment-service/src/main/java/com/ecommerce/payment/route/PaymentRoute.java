package com.ecommerce.payment.route;

import com.ecommerce.payment.model.OrderEvent;
import com.ecommerce.payment.model.PaymentEvent;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;
import java.util.UUID;

@Slf4j
@Component
public class PaymentRoute extends RouteBuilder {

    @Override
    public void configure() {

        onException(Exception.class)
            .maximumRedeliveries(2)
            .redeliveryDelay(3000)
            .handled(true)
            .log("Payment exception: ${exception.message}")
            .marshal().json(JsonLibrary.Jackson)
            .to("kafka:payment.failed?brokers={{kafka.brokers}}");

        // Consume inventory.reserved -> charge customer
        from("kafka:inventory.reserved?brokers={{kafka.brokers}}&groupId=payment-service&autoOffsetReset=earliest")
            .routeId("process-payment")
            .unmarshal().json(JsonLibrary.Jackson, OrderEvent.class)
            .log("Processing payment: order=${body.orderId} amount=${body.totalAmount}")
            .circuitBreaker()
                .resilience4jConfiguration()
                    .slidingWindowSize(10)
                    .failureRateThreshold(50)
                    .waitDurationInOpenState(10000)
                .end()
                .to("direct:call-payment-gateway")
            .onFallback()
                .process(exchange -> {
                    OrderEvent o = exchange.getIn().getBody(OrderEvent.class);
                    exchange.getIn().setBody(
                        new PaymentEvent(o.getOrderId(), false, null, "GATEWAY_UNAVAILABLE"));
                })
            .end()
            .marshal().json(JsonLibrary.Jackson)
            .to("kafka:payment.processed?brokers={{kafka.brokers}}")
            .log("Payment result published");

        // Simulated payment gateway (replace with real Stripe/PayPal call)
        from("direct:call-payment-gateway")
            .routeId("call-gateway")
            .process(exchange -> {
                OrderEvent o = exchange.getIn().getBody(OrderEvent.class);
                // Orders over $10000 fail (simulation)
                boolean ok = o.getTotalAmount() <= 10000.0;
                String txn = ok
                    ? "TXN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase()
                    : null;
                exchange.getIn().setBody(
                    new PaymentEvent(o.getOrderId(), ok, txn, ok ? null : "INSUFFICIENT_FUNDS"));
                log.info("Gateway response: order={} success={} txn={}", o.getOrderId(), ok, txn);
            });

        // Handle out-of-stock orders from inventory
        from("kafka:inventory.unavailable?brokers={{kafka.brokers}}&groupId=payment-service&autoOffsetReset=earliest")
            .routeId("handle-out-of-stock")
            .unmarshal().json(JsonLibrary.Jackson, OrderEvent.class)
            .process(exchange -> {
                OrderEvent o = exchange.getIn().getBody(OrderEvent.class);
                exchange.getIn().setBody(
                    new PaymentEvent(o.getOrderId(), false, null, "OUT_OF_STOCK"));
            })
            .marshal().json(JsonLibrary.Jackson)
            .to("kafka:payment.processed?brokers={{kafka.brokers}}")
            .log("Out-of-stock handled for order: ${body}");

        from("servlet:/health")
            .routeId("payment-health")
            .setHeader("Content-Type", constant("application/json"))
            .setBody(constant("{\"service\":\"payment-service\",\"status\":\"UP\"}"));
    }
}
