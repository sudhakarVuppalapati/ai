package com.ecommerce.inventory.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OrderEvent {
    private String orderId;
    private String customerId;
    private String productId;
    private int quantity;
    private double totalAmount;
    private String region;
    private String status;
}
