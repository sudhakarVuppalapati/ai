package com.ecommerce.inventory.route;

import com.ecommerce.inventory.model.InventoryItem;
import com.ecommerce.inventory.model.OrderEvent;
import com.ecommerce.inventory.repository.InventoryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.processor.idempotent.MemoryIdempotentRepository;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Slf4j
@Component
@RequiredArgsConstructor
public class InventoryRoute extends RouteBuilder {

    private final InventoryRepository inventoryRepository;

    @Override
    public void configure() {

        onException(Exception.class)
            .handled(true)
            .log("Inventory error: ${exception.message}");

        // Route 1: Consume order.created from Kafka
        from("kafka:order.created?brokers={{kafka.brokers}}&groupId=inventory-service&autoOffsetReset=earliest")
            .routeId("check-inventory")

            // Idempotent: skip duplicate messages
            .idempotentConsumer(
                jsonpath("$.orderId"),
                MemoryIdempotentRepository.memoryIdempotentRepository(1000)
            )
            .unmarshal().json(JsonLibrary.Jackson, OrderEvent.class)
            .log("Checking stock for order: ${body.orderId} product: ${body.productId}")

            // Check and reserve stock
            .process(exchange -> {
                OrderEvent order = exchange.getIn().getBody(OrderEvent.class);
                Optional<InventoryItem> itemOpt = inventoryRepository.findByProductId(order.getProductId());

                boolean available = false;
                if (itemOpt.isPresent()) {
                    InventoryItem item = itemOpt.get();
                    if (item.getAvailableStock() >= order.getQuantity()) {
                        // Reserve stock
                        item.setAvailableStock(item.getAvailableStock() - order.getQuantity());
                        item.setReservedStock(item.getReservedStock() + order.getQuantity());
                        inventoryRepository.save(item);
                        available = true;
                        log.info("Reserved {} units of {} for order {}", order.getQuantity(), order.getProductId(), order.getOrderId());
                    }
                }
                exchange.getIn().setHeader("stockAvailable", available);
            })

            // Route based on stock availability
            .choice()
                .when(header("stockAvailable").isEqualTo(true))
                    .marshal().json(JsonLibrary.Jackson)
                    .to("kafka:inventory.reserved?brokers={{kafka.brokers}}")
                    .log("Stock reserved — published to inventory.reserved")
                .otherwise()
                    .marshal().json(JsonLibrary.Jackson)
                    .to("kafka:inventory.unavailable?brokers={{kafka.brokers}}")
                    .log("Out of stock — published to inventory.unavailable")
            .end();

        // Route 2: Release reserved stock on payment failure
        from("kafka:payment.failed?brokers={{kafka.brokers}}&groupId=inventory-service&autoOffsetReset=earliest")
            .routeId("release-stock")
            .unmarshal().json(JsonLibrary.Jackson, OrderEvent.class)
            .process(exchange -> {
                OrderEvent order = exchange.getIn().getBody(OrderEvent.class);
                inventoryRepository.findByProductId(order.getProductId()).ifPresent(item -> {
                    item.setAvailableStock(item.getAvailableStock() + order.getQuantity());
                    item.setReservedStock(Math.max(0, item.getReservedStock() - order.getQuantity()));
                    inventoryRepository.save(item);
                    log.info("Released {} units of {} due to payment failure", order.getQuantity(), order.getProductId());
                });
            })
            .log("Stock released for failed order: ${body.orderId}");

        // Route 3: Health check
        from("servlet:/health")
            .routeId("inventory-health")
            .setHeader("Content-Type", constant("application/json"))
            .setBody(constant("{\"service\": \"inventory-service\", \"status\": \"UP\"}"));
    }
}
