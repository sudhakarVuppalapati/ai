package com.ecommerce.inventory.config;

import com.ecommerce.inventory.model.InventoryItem;
import com.ecommerce.inventory.repository.InventoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataLoader implements CommandLineRunner {

    private final InventoryRepository inventoryRepository;

    @Override
    public void run(String... args) {
        inventoryRepository.save(new InventoryItem(null, "PROD-001", "Laptop Pro 15", 100, 0));
        inventoryRepository.save(new InventoryItem(null, "PROD-002", "Wireless Mouse", 500, 0));
        inventoryRepository.save(new InventoryItem(null, "PROD-003", "USB-C Hub", 250, 0));
        inventoryRepository.save(new InventoryItem(null, "PROD-004", "Mechanical Keyboard", 75, 0));
    }
}
