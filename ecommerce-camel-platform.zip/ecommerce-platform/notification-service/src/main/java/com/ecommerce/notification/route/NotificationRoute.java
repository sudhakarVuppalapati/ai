package com.ecommerce.notification.route;

import com.ecommerce.notification.model.PaymentEvent;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class NotificationRoute extends RouteBuilder {

    @Override
    public void configure() {

        onException(Exception.class)
            .handled(true)
            .log("Notification error (non-fatal): ${exception.message}");

        // Consume payment.processed -> fan out notifications
        from("kafka:payment.processed?brokers={{kafka.brokers}}&groupId=notification-service&autoOffsetReset=earliest")
            .routeId("send-notifications")
            .unmarshal().json(JsonLibrary.Jackson, PaymentEvent.class)
            .log("Sending notifications for order: ${body.orderId} success=${body.success}")

            // Multicast: send to all three channels in parallel
            .multicast()
                .parallelProcessing()
                .to("direct:send-email", "direct:send-sms", "direct:send-push")
            .end()
            .log("All notifications dispatched for ${body.orderId}");


        // Email notification
        from("direct:send-email")
            .routeId("send-email")
            .process(exchange -> {
                PaymentEvent event = exchange.getIn().getBody(PaymentEvent.class);
                String subject = event.isSuccess()
                    ? "Order Confirmed: " + event.getOrderId()
                    : "Order Failed: " + event.getOrderId();
                String body = event.isSuccess()
                    ? String.format("Your order %s has been confirmed! Transaction ID: %s",
                        event.getOrderId(), event.getTransactionId())
                    : String.format("Sorry, your order %s could not be processed. Reason: %s",
                        event.getOrderId(), event.getFailureReason());

                exchange.getIn().setHeader("subject", subject);
                exchange.getIn().setBody(body);
                log.info("[EMAIL] To: customer@example.com | Subject: {} | Body: {}", subject, body);
                // Real impl: .to("smtp://smtp.gmail.com?username=xx&password=yy&to=customer@example.com")
            });


        // SMS notification
        from("direct:send-sms")
            .routeId("send-sms")
            .process(exchange -> {
                PaymentEvent event = exchange.getIn().getBody(PaymentEvent.class);
                String message = event.isSuccess()
                    ? "Order " + event.getOrderId() + " confirmed! Txn: " + event.getTransactionId()
                    : "Order " + event.getOrderId() + " failed: " + event.getFailureReason();
                log.info("[SMS] To: +1234567890 | Message: {}", message);
                // Real impl: call Twilio REST API
            });


        // Push notification
        from("direct:send-push")
            .routeId("send-push")
            .process(exchange -> {
                PaymentEvent event = exchange.getIn().getBody(PaymentEvent.class);
                String title = event.isSuccess() ? "Order Confirmed" : "Order Failed";
                String body  = event.isSuccess()
                    ? "Your payment was successful"
                    : "Payment failed: " + event.getFailureReason();
                log.info("[PUSH] Title: {} | Body: {} | OrderId: {}", title, body, event.getOrderId());
                // Real impl: call FCM/APNs API
            });


        // Health check
        from("servlet:/health")
            .routeId("notification-health")
            .setHeader("Content-Type", constant("application/json"))
            .setBody(constant("{\"service\":\"notification-service\",\"status\":\"UP\"}"));
    }
}
