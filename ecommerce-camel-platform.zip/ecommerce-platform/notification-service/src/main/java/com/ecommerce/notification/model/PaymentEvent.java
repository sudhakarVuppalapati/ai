package com.ecommerce.notification.model;
import lombok.Data; import lombok.NoArgsConstructor;
@Data @NoArgsConstructor
public class PaymentEvent {
    private String orderId;
    private boolean success;
    private String transactionId;
    private String failureReason;
}
