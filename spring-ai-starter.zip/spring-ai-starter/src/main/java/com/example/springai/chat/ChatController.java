package com.example.springai.chat;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/api/chat")
public class ChatController {

    private final ChatService chatService;

    public ChatController(ChatService chatService) {
        this.chatService = chatService;
    }

    @PostMapping
    public ChatResponse chat(@RequestBody ChatRequest request) {
        String response = chatService.chat(request.message());
        return new ChatResponse(response);
    }

    @PostMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<String> streamChat(@RequestBody ChatRequest request) {
        return chatService.streamChat(request.message());
    }

    @PostMapping("/conversation/{conversationId}")
    public ChatResponse conversationalChat(
            @RequestBody ChatRequest request,
            @PathVariable String conversationId) {
        String response = chatService.conversationalChat(request.message(), conversationId);
        return new ChatResponse(response);
    }

    @PostMapping("/explain")
    public ChatResponse explain(
            @RequestParam String topic,
            @RequestParam(defaultValue = "beginners") String audience) {
        return new ChatResponse(chatService.chatWithTemplate(topic, audience));
    }

    // ── Records ──────────────────────────────────────────────────────────────

    public record ChatRequest(String message) {}
    public record ChatResponse(String response) {}
}
