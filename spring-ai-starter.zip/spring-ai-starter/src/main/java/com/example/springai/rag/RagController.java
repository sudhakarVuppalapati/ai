package com.example.springai.rag;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/rag")
public class RagController {

    private final RagService ragService;

    public RagController(RagService ragService) {
        this.ragService = ragService;
    }

    /** Ingest a file (PDF, Word, HTML, Markdown…) */
    @PostMapping("/ingest")
    public ResponseEntity<IngestResponse> ingest(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "source", required = false) String source) throws IOException {

        String sourceName = source != null ? source : file.getOriginalFilename();
        int chunks = ragService.ingestFile(file, sourceName);
        return ResponseEntity.ok(new IngestResponse(sourceName, chunks));
    }

    /** Ingest plain text snippets */
    @PostMapping("/ingest/text")
    public ResponseEntity<IngestResponse> ingestText(@RequestBody IngestTextRequest request) {
        int chunks = ragService.ingestText(request.texts(), request.source());
        return ResponseEntity.ok(new IngestResponse(request.source(), chunks));
    }

    /** Ask a question — triggers retrieval + generation */
    @PostMapping("/query")
    public RagService.RagResponse query(@RequestBody QueryRequest request) {
        return ragService.query(request.question());
    }

    // ── Records ──────────────────────────────────────────────────────────────
    public record IngestResponse(String source, int chunksCreated) {}
    public record IngestTextRequest(List<String> texts, String source) {}
    public record QueryRequest(String question) {}
}
