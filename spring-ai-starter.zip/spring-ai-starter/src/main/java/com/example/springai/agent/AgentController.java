package com.example.springai.agent;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/agent")
public class AgentController {

    private final AgentService agentService;

    public AgentController(AgentService agentService) {
        this.agentService = agentService;
    }

    @PostMapping("/run")
    public AgentService.AgentResult runTask(@RequestBody TaskRequest request) {
        return agentService.run(request.task());
    }

    @PostMapping("/research")
    public AgentService.AgentResult research(@RequestBody AgentService.ResearchRequest request) {
        return agentService.research(request);
    }

    public record TaskRequest(String task) {}
}
