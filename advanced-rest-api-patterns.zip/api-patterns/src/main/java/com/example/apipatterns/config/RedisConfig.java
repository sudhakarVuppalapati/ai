package com.example.apipatterns.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * Redis configuration for idempotency key caching (Pattern 1).
 *
 * The app works without Redis — idempotency falls back to the DB
 * (via PaymentRepository.findByIdempotencyKey).
 *
 * Redis is the preferred solution for high-traffic APIs because:
 * - O(1) lookup by key
 * - Built-in TTL expiry (keys auto-delete after 24-48 hours)
 * - Can handle concurrent requests with atomic operations
 *
 * For production: set spring.data.redis.host in application.properties.
 * For local dev:  comment out Redis dependencies — DB fallback handles it.
 */
@Configuration
public class RedisConfig {

    @Bean
    @ConditionalOnMissingBean(RedisTemplate.class)
    public RedisTemplate<String, String> redisTemplate(RedisConnectionFactory factory) {
        RedisTemplate<String, String> template = new RedisTemplate<>();
        template.setConnectionFactory(factory);
        template.setKeySerializer(new StringRedisSerializer());
        template.setValueSerializer(new StringRedisSerializer());
        template.afterPropertiesSet();
        return template;
    }
}
