package com.example.apipatterns.config;

import com.example.apipatterns.entity.Order;
import com.example.apipatterns.entity.User;
import com.example.apipatterns.repository.OrderRepository;
import com.example.apipatterns.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * Seeds the H2 in-memory DB with test data on startup.
 * No external setup needed — just run the app and hit the endpoints.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class DataLoader implements CommandLineRunner {

    private final UserRepository userRepository;
    private final OrderRepository orderRepository;

    @Override
    public void run(String... args) {
        // ── Seed Users ────────────────────────────────────────────────────────
        User alice = new User();
        alice.setName("Alice Kumar");
        alice.setEmail("alice@example.com");
        userRepository.save(alice);

        User bob = new User();
        bob.setName("Bob Sharma");
        bob.setEmail("bob@example.com");
        userRepository.save(bob);

        // ── Seed Orders ───────────────────────────────────────────────────────
        Order o1 = new Order();
        o1.setUserId(alice.getId());
        o1.setStatus("PENDING");
        o1.setTotalAmount(new BigDecimal("1499.00"));
        o1.setShippingAddress("42 MG Road, Chennai, TN 600001");
        o1.setNotes("Leave at door");
        orderRepository.save(o1);

        Order o2 = new Order();
        o2.setUserId(alice.getId());
        o2.setStatus("CONFIRMED");
        o2.setTotalAmount(new BigDecimal("3299.50"));
        o2.setShippingAddress("42 MG Road, Chennai, TN 600001");
        orderRepository.save(o2);

        Order o3 = new Order();
        o3.setUserId(bob.getId());
        o3.setStatus("SHIPPED");
        o3.setTotalAmount(new BigDecimal("899.00"));
        o3.setShippingAddress("7 Anna Nagar, Chennai, TN 600040");
        orderRepository.save(o3);

        log.info("═══════════════════════════════════════════════════════════");
        log.info("  Test data loaded. Try these endpoints:");
        log.info("");
        log.info("  PATTERN 1 — Idempotency:");
        log.info("    POST /api/v2/payments");
        log.info("    Header: Idempotency-Key: <any-uuid>");
        log.info("");
        log.info("  PATTERN 2 — Optimistic Locking:");
        log.info("    GET  /api/v2/orders/1    (note the version field)");
        log.info("    PUT  /api/v2/orders/1    body: {{version:0, status:CONFIRMED}}");
        log.info("    PUT  /api/v2/orders/1    same body again → 409 Conflict");
        log.info("");
        log.info("  PATTERN 3 — Deprecation:");
        log.info("    GET  /api/v1/orders?userId=1   (check response headers)");
        log.info("");
        log.info("  PATTERN 4 — Domain Design:");
        log.info("    GET  /api/v2/users/1/orders");
        log.info("    GET  /api/v2/users/1/orders?status=PENDING");
        log.info("");
        log.info("  H2 Console: http://localhost:8080/h2-console");
        log.info("═══════════════════════════════════════════════════════════");
    }
}
