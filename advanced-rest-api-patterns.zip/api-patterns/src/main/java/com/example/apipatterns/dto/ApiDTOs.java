package com.example.apipatterns.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

// ─────────────────────────────────────────────────────────────────────────────
// PAYMENT  (Pattern 1 — Idempotency)
// ─────────────────────────────────────────────────────────────────────────────

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class PaymentRequest {
    @NotNull  public Long orderId;
    @NotNull  public Long userId;
    @NotNull @DecimalMin("0.01") public BigDecimal amount;
    @NotBlank public String currency;
}

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class PaymentResponse {
    public Long paymentId;
    public String status;
    public String transactionReference;
    public BigDecimal amount;
    public String currency;
    public LocalDateTime processedAt;
    /** "PROCESSED" = fresh action taken; "REPLAYED" = duplicate, returning cached result */
    public String idempotencyResult;
}

// ─────────────────────────────────────────────────────────────────────────────
// ORDER  (Pattern 2 — Optimistic Locking | Pattern 4 — Domain Design)
// ─────────────────────────────────────────────────────────────────────────────

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class OrderRequest {
    @NotNull  public Long userId;
    @NotBlank public String shippingAddress;
    public String notes;
    @NotNull @DecimalMin("0.01") public BigDecimal totalAmount;
}

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class OrderUpdateRequest {
    /**
     * PATTERN 2 — Client sends the version they read.
     * If it doesn't match what's in the DB, we return 409 Conflict.
     * Prevents the "lost update" problem: last-write-wins is replaced with
     * "stale-write-rejected".
     */
    @NotNull(message = "version is required — read the order first, include its version here")
    public Long version;

    public String status;
    public String shippingAddress;
    public String notes;
}

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class OrderResponse {
    public Long id;
    public Long userId;
    public String status;
    public BigDecimal totalAmount;
    public String shippingAddress;
    public String notes;
    public LocalDateTime createdAt;
    public LocalDateTime updatedAt;
    /**
     * PATTERN 2 — Always returned so the client can send it back on the next update.
     * Think of it like a token: "prove you've seen the latest state before writing."
     */
    public Long version;
}

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class UserOrdersResponse {
    public Long userId;
    public String userName;
    public List<OrderResponse> orders;
    public int totalOrders;
}

// ─────────────────────────────────────────────────────────────────────────────
// ERRORS
// ─────────────────────────────────────────────────────────────────────────────

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class ErrorResponse {
    public String error;
    public String message;
    public int status;
    public LocalDateTime timestamp;
}
