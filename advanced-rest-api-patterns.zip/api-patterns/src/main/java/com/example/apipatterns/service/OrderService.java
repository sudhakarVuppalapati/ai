package com.example.apipatterns.service;

import com.example.apipatterns.dto.*;
import com.example.apipatterns.entity.Order;
import com.example.apipatterns.entity.User;
import com.example.apipatterns.exception.OptimisticLockConflictException;
import com.example.apipatterns.exception.ResourceNotFoundException;
import com.example.apipatterns.repository.OrderRepository;
import com.example.apipatterns.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * ═══════════════════════════════════════════════════════════════════════
 * PATTERN 2: OPTIMISTIC LOCKING — Safe Concurrent Updates
 * ═══════════════════════════════════════════════════════════════════════
 *
 * PROBLEM:
 *   Two users open an order, both edit it, both try to save.
 *   Without concurrency control:
 *     - User A saves their changes ✅
 *     - User B's save silently overwrites User A's changes ❌ (lost update)
 *
 * SOLUTION — OPTIMISTIC LOCKING:
 *   - Every order has a `version` field (Long, starts at 0)
 *   - When you UPDATE, JPA adds: WHERE id=? AND version=?
 *   - If the version doesn't match (someone else updated), 0 rows affected
 *   - JPA throws OptimisticLockException → we return 409 Conflict
 *   - Client must re-fetch, review changes, and retry
 *
 * WHY "OPTIMISTIC"?
 *   It's optimistic because it assumes conflicts are rare.
 *   It doesn't lock the row on read — it only checks at write time.
 *   Far better performance than pessimistic locking (no DB row locks held).
 *
 * ═══════════════════════════════════════════════════════════════════════
 * PATTERN 4: DOMAIN-DRIVEN DESIGN — Business-Centric Resources
 * ═══════════════════════════════════════════════════════════════════════
 *
 * PROBLEM:
 *   Mid-level: GET /api/orders?user_id=5  (database-centric, flat)
 *
 * SOLUTION:
 *   Senior:   GET /api/users/5/orders    (domain-centric, nested)
 *
 *   The URL reflects the business relationship, not the DB schema.
 *   getUserOrders() returns a UserOrdersResponse that aggregates
 *   both user info and their orders in one domain-coherent response.
 *
 * ═══════════════════════════════════════════════════════════════════════
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class OrderService {

    private final OrderRepository orderRepository;
    private final UserRepository userRepository;

    // ── Create an order ───────────────────────────────────────────────────────
    @Transactional
    public OrderResponse createOrder(OrderRequest request) {
        userRepository.findById(request.userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + request.userId));

        Order order = new Order();
        order.setUserId(request.userId);
        order.setStatus("PENDING");
        order.setTotalAmount(request.totalAmount);
        order.setShippingAddress(request.shippingAddress);
        order.setNotes(request.notes);

        Order saved = orderRepository.save(order);
        log.info("Created order {} for user {} (version={})", saved.getId(), saved.getUserId(), saved.getVersion());
        return toResponse(saved);
    }

    // ── Get a single order ────────────────────────────────────────────────────
    @Transactional(readOnly = true)
    public OrderResponse getOrder(Long orderId) {
        Order order = findOrder(orderId);
        return toResponse(order);
    }

    /**
     * ─────────────────────────────────────────────────────────────────────────
     * PATTERN 2: OPTIMISTIC LOCK UPDATE
     *
     * How it works step by step:
     *   1. Client GETs /api/v2/orders/123 → receives {version: 5, status: "PENDING", ...}
     *   2. Client decides to update status to "CONFIRMED"
     *   3. Client PUTs /api/v2/orders/123 with body {version: 5, status: "CONFIRMED"}
     *
     *   HAPPY PATH: No one else updated since step 1
     *     - Our check: request.version (5) == db.version (5) ✅
     *     - JPA UPDATE: WHERE id=123 AND version=5  → 1 row affected
     *     - JPA increments version to 6
     *     - Response: {version: 6, ...}
     *
     *   CONFLICT PATH: Someone else updated between steps 1 and 3
     *     - Meanwhile: User B updated the order → version is now 6 in DB
     *     - Our check: request.version (5) != db.version (6) ❌
     *     - Response: 409 Conflict — "re-fetch and retry"
     * ─────────────────────────────────────────────────────────────────────────
     */
    @Transactional
    public OrderResponse updateOrder(Long orderId, OrderUpdateRequest request) {
        Order order = findOrder(orderId);

        // ── Explicit version check (before JPA's internal check) ──────────────
        // This gives us a clear, readable error message instead of a raw JPA exception
        if (!order.getVersion().equals(request.version)) {
            log.warn("Version conflict on order {}: client sent version={}, DB has version={}",
                    orderId, request.version, order.getVersion());
            throw new OptimisticLockConflictException(
                    String.format(
                        "Order %d was modified since you last fetched it. " +
                        "You sent version=%d but the current version is %d. " +
                        "Re-fetch the order (GET /api/v2/orders/%d) and retry with version=%d.",
                        orderId, request.version, order.getVersion(), orderId, order.getVersion()
                    )
            );
        }

        // ── Apply the updates ─────────────────────────────────────────────────
        if (request.status != null)          order.setStatus(request.status);
        if (request.shippingAddress != null) order.setShippingAddress(request.shippingAddress);
        if (request.notes != null)           order.setNotes(request.notes);

        // JPA's @Version field auto-increments here.
        // If ANOTHER thread snuck in between our check and this save,
        // JPA's WHERE version=? clause will catch it and throw OptimisticLockException.
        try {
            Order saved = orderRepository.save(order);
            log.info("Updated order {} — version {} → {}", orderId, request.version, saved.getVersion());
            return toResponse(saved);
        } catch (OptimisticLockingFailureException ex) {
            // Race condition: another thread updated between our check and the save
            throw new OptimisticLockConflictException(
                    "Order " + orderId + " was concurrently modified. Re-fetch and retry."
            );
        }
    }

    /**
     * ─────────────────────────────────────────────────────────────────────────
     * PATTERN 4: DOMAIN-DRIVEN RESOURCE DESIGN
     *
     * Instead of:   GET /api/orders?userId=5  (flat, DB-centric)
     * We expose:    GET /api/users/5/orders   (nested, domain-centric)
     *
     * The URL reflects the business hierarchy: a user HAS orders.
     * The response aggregates user + orders into one domain object,
     * reducing the need for multiple client-side calls.
     * ─────────────────────────────────────────────────────────────────────────
     */
    @Transactional(readOnly = true)
    public UserOrdersResponse getUserOrders(Long userId, String status) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userId));

        List<Order> orders = (status != null)
                ? orderRepository.findByUserIdAndStatus(userId, status)
                : orderRepository.findByUserId(userId);

        List<OrderResponse> orderResponses = orders.stream()
                .map(this::toResponse)
                .collect(Collectors.toList());

        return UserOrdersResponse.builder()
                .userId(user.getId())
                .userName(user.getName())
                .orders(orderResponses)
                .totalOrders(orderResponses.size())
                .build();
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private Order findOrder(Long orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found: " + orderId));
    }

    private OrderResponse toResponse(Order order) {
        return OrderResponse.builder()
                .id(order.getId())
                .userId(order.getUserId())
                .status(order.getStatus())
                .totalAmount(order.getTotalAmount())
                .shippingAddress(order.getShippingAddress())
                .notes(order.getNotes())
                .createdAt(order.getCreatedAt())
                .updatedAt(order.getUpdatedAt())
                .version(order.getVersion())  // Always expose version for optimistic locking
                .build();
    }
}
