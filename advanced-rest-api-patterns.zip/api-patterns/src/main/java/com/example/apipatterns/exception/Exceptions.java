package com.example.apipatterns.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

// ─── Resource Not Found ───────────────────────────────────────────────────────

@ResponseStatus(HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}

// ─── Conflict / Optimistic Lock Violation ────────────────────────────────────

/**
 * PATTERN 2 — Thrown when a client sends an update with a stale version number.
 * Translates to HTTP 409 Conflict.
 *
 * Scenario:
 *   - User A reads Order{version=2}, starts editing
 *   - User B reads Order{version=2}, edits and saves → version becomes 3
 *   - User A tries to save with version=2 → this exception is thrown
 *   - Client receives 409, knows they must re-fetch and retry
 */
@ResponseStatus(HttpStatus.CONFLICT)
public class OptimisticLockConflictException extends RuntimeException {
    public OptimisticLockConflictException(String message) {
        super(message);
    }
}

// ─── Duplicate Idempotency Key (shouldn't normally surface to API layer) ─────

/**
 * PATTERN 1 — Thrown only on edge-case race condition where two identical
 * requests arrive at the exact same millisecond before either is stored.
 * Normal retries are handled gracefully (replay cached result).
 */
@ResponseStatus(HttpStatus.CONFLICT)
public class DuplicateRequestException extends RuntimeException {
    public DuplicateRequestException(String message) {
        super(message);
    }
}

// ─── Missing Idempotency Key ──────────────────────────────────────────────────

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class MissingIdempotencyKeyException extends RuntimeException {
    public MissingIdempotencyKeyException() {
        super("Idempotency-Key header is required for this endpoint. " +
              "Generate a UUID and include it as: Idempotency-Key: <uuid>. " +
              "Reuse the same key if you need to retry.");
    }
}
