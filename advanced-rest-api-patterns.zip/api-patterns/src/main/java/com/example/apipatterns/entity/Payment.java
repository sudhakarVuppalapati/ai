package com.example.apipatterns.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * PATTERN 1 — IDEMPOTENCY
 *
 * Stores the idempotency key alongside the payment so we can detect duplicate requests.
 * The idempotencyKey column has a UNIQUE constraint — a second INSERT with the same key
 * will fail at the DB level, giving us a hard guarantee beyond the application layer.
 */
@Entity
@Table(name = "payments",
       uniqueConstraints = @UniqueConstraint(columnNames = "idempotencyKey"))
@Data
@NoArgsConstructor
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long orderId;

    private Long userId;

    /**
     * THE IDEMPOTENCY KEY
     * Sent by the client as a header: Idempotency-Key: <uuid>
     * Stored here so we can look up and return the same response on retry.
     * UNIQUE constraint = database-level guarantee against duplicates.
     */
    @Column(unique = true, nullable = false)
    private String idempotencyKey;

    private BigDecimal amount;

    private String currency;

    private String status;              // PENDING, SUCCESS, FAILED

    private String transactionReference; // external payment processor ref

    private LocalDateTime processedAt;

    @PrePersist
    protected void onCreate() {
        processedAt = LocalDateTime.now();
    }
}
