package com.example.apipatterns.service;

import com.example.apipatterns.dto.PaymentResponse;
import com.example.apipatterns.dto.PaymentRequest;
import com.example.apipatterns.entity.Payment;
import com.example.apipatterns.exception.MissingIdempotencyKeyException;
import com.example.apipatterns.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.UUID;

/**
 * ═══════════════════════════════════════════════════════════════════════
 * PATTERN 1: IDEMPOTENCY KEYS — Safe Retries
 * ═══════════════════════════════════════════════════════════════════════
 *
 * PROBLEM:
 *   Network failures happen. When a client POSTs a payment and the
 *   response is lost in transit, they don't know if the payment went through.
 *   Without idempotency, retrying = double charge. Bad.
 *
 * SOLUTION:
 *   Client generates a UUID once per logical action and sends it as a header:
 *     Idempotency-Key: 550e8400-e29b-41d4-a716-446655440000
 *
 *   Server stores the key + result after processing.
 *   On retry with the same key → return stored result without processing again.
 *
 * FLOW:
 *   Request arrives
 *     ↓
 *   Has Idempotency-Key header?  NO → 400 Bad Request
 *     ↓ YES
 *   Key seen before?  YES → return stored result (REPLAYED)
 *     ↓ NO
 *   Process payment → store key + result → return result (PROCESSED)
 *
 * REAL-WORLD EXAMPLE: Stripe uses this for all POST endpoints.
 * ═══════════════════════════════════════════════════════════════════════
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class PaymentService {

    private final PaymentRepository paymentRepository;

    @Transactional
    public PaymentResponse processPayment(String idempotencyKey, PaymentRequest request) {

        // ── Step 1: Validate idempotency key ─────────────────────────────────
        if (idempotencyKey == null || idempotencyKey.isBlank()) {
            throw new MissingIdempotencyKeyException();
        }

        // ── Step 2: Check if we've seen this key before ───────────────────────
        Optional<Payment> existingPayment = paymentRepository.findByIdempotencyKey(idempotencyKey);

        if (existingPayment.isPresent()) {
            // ── DUPLICATE REQUEST: replay the stored result ───────────────────
            Payment payment = existingPayment.get();
            log.info("⟳  REPLAYED payment for idempotency key: {} — returning stored result", idempotencyKey);

            return PaymentResponse.builder()
                    .paymentId(payment.getId())
                    .status(payment.getStatus())
                    .transactionReference(payment.getTransactionReference())
                    .amount(payment.getAmount())
                    .currency(payment.getCurrency())
                    .processedAt(payment.getProcessedAt())
                    .idempotencyResult("REPLAYED")   // ← tells client this was a duplicate
                    .build();
        }

        // ── Step 3: FIRST REQUEST — actually process it ───────────────────────
        log.info("✅  PROCESSING new payment for idempotency key: {}", idempotencyKey);

        // Simulate payment processor call (Stripe, Razorpay, etc.)
        String transactionRef = simulatePaymentProcessor(request);

        // ── Step 4: Store the key + result (so retries are idempotent) ────────
        Payment payment = new Payment();
        payment.setIdempotencyKey(idempotencyKey);
        payment.setOrderId(request.orderId);
        payment.setUserId(request.userId);
        payment.setAmount(request.amount);
        payment.setCurrency(request.currency);
        payment.setStatus("SUCCESS");
        payment.setTransactionReference(transactionRef);
        paymentRepository.save(payment);

        return PaymentResponse.builder()
                .paymentId(payment.getId())
                .status("SUCCESS")
                .transactionReference(transactionRef)
                .amount(request.amount)
                .currency(request.currency)
                .processedAt(payment.getProcessedAt())
                .idempotencyResult("PROCESSED")   // ← tells client this was freshly processed
                .build();
    }

    /**
     * Simulates calling an external payment processor.
     * In production: Stripe, Razorpay, PayU, etc.
     */
    private String simulatePaymentProcessor(PaymentRequest request) {
        // Simulate 200ms processing time
        try { Thread.sleep(200); } catch (InterruptedException ignored) {}
        return "TXN-" + UUID.randomUUID().toString().substring(0, 12).toUpperCase();
    }
}
