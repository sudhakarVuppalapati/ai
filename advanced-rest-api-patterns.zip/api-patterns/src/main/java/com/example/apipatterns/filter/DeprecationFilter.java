package com.example.apipatterns.filter;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Map;

/**
 * ═══════════════════════════════════════════════════════════════════════
 * PATTERN 3: GRACEFUL DEPRECATION — Evolving API Contracts
 * ═══════════════════════════════════════════════════════════════════════
 *
 * PROBLEM:
 *   Mid-level dev removes /v1 endpoint → all clients break overnight.
 *
 * SOLUTION — Three-Phase Deprecation:
 *
 *   Phase 1 — ANNOUNCE (add response headers, keep working):
 *     Deprecation: true
 *     Sunset: Sat, 31 Dec 2025 23:59:59 GMT
 *     Link: <https://api.example.com/v2/orders>; rel="successor-version"
 *
 *   Phase 2 — WARN (closer to sunset, add stronger signals):
 *     X-Deprecation-Warning: This endpoint will be removed on 2025-12-31
 *
 *   Phase 3 — REMOVE (after sunset date, return 410 Gone):
 *     HTTP 410 Gone
 *     Body: { "error": "ENDPOINT_REMOVED", "migrateTo": "/api/v2/..." }
 *
 * WHY HEADERS?
 *   - Clients/gateways can parse them programmatically
 *   - Logging infrastructure can alert on deprecated endpoint usage
 *   - Follows RFC 8594 (Sunset HTTP header) — an IETF standard
 *
 * This filter adds deprecation headers to ALL /api/v1/** responses.
 * ═══════════════════════════════════════════════════════════════════════
 */
@Component
public class DeprecationFilter implements Filter {

    /**
     * Maps deprecated path prefixes to their migration targets.
     * Key = deprecated path prefix
     * Value = replacement path
     */
    private static final Map<String, String> DEPRECATED_PATHS = Map.of(
            "/api/v1/orders",   "/api/v2/users/{userId}/orders",
            "/api/v1/payments", "/api/v2/payments"
    );

    // Sunset date: after this, we will return 410 Gone
    private static final String SUNSET_DATE = "Sat, 31 Dec 2025 23:59:59 GMT";
    private static final boolean PAST_SUNSET = false; // set to true to enable 410 behavior

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest  httpReq  = (HttpServletRequest) req;
        HttpServletResponse httpRes  = (HttpServletResponse) res;
        String path = httpReq.getRequestURI();

        // ── Check if request targets a deprecated path ────────────────────────
        String matchedDeprecated = DEPRECATED_PATHS.keySet().stream()
                .filter(path::startsWith)
                .findFirst()
                .orElse(null);

        if (matchedDeprecated != null) {
            String successor = DEPRECATED_PATHS.get(matchedDeprecated);

            if (PAST_SUNSET) {
                // ── Phase 3: REMOVE — return 410 Gone ────────────────────────
                httpRes.setStatus(HttpServletResponse.SC_NOT_FOUND); // 410
                httpRes.setContentType("application/json");
                httpRes.getWriter().write(String.format("""
                    {
                      "error": "ENDPOINT_REMOVED",
                      "message": "This endpoint was removed on 2025-12-31. Please migrate.",
                      "migrateTo": "%s",
                      "documentation": "https://docs.example.com/migration-guide"
                    }
                    """, successor));
                return; // Short-circuit — don't forward to controller
            }

            // ── Phase 1 & 2: WARN — add deprecation headers, still works ─────
            // RFC 8594: Sunset header announces removal date
            httpRes.setHeader("Deprecation",  "true");
            httpRes.setHeader("Sunset",        SUNSET_DATE);

            // Link header: machine-readable pointer to the replacement
            httpRes.setHeader("Link",
                    String.format("<https://api.example.com%s>; rel=\"successor-version\"", successor));

            // Human-readable warning (also parseable by API gateways)
            httpRes.setHeader("X-Deprecation-Warning",
                    "This endpoint is deprecated and will be removed on 2025-12-31. " +
                    "Please migrate to: " + successor);

            // Log every hit on a deprecated endpoint so you can track which clients
            // haven't migrated yet and reach out proactively
            System.out.printf("[DEPRECATION] Client hit deprecated path: %s (User-Agent: %s)%n",
                    path, httpReq.getHeader("User-Agent"));
        }

        chain.doFilter(req, res);
    }
}
