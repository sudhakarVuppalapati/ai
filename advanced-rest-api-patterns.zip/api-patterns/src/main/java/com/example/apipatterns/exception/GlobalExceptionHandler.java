package com.example.apipatterns.exception;

import com.example.apipatterns.dto.ErrorResponse;
import jakarta.persistence.OptimisticLockException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.stream.Collectors;

/**
 * Centralized error handling.
 *
 * Key mappings:
 *   OptimisticLockException / OptimisticLockingFailureException
 *     → 409 Conflict  (Pattern 2: concurrent update detected)
 *
 *   MissingIdempotencyKeyException
 *     → 400 Bad Request (Pattern 1: Idempotency-Key header missing)
 *
 *   OptimisticLockConflictException
 *     → 409 Conflict  (Pattern 2: version mismatch)
 */
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    // ── Pattern 2: JPA throws this when version doesn't match ────────────────
    @ExceptionHandler({OptimisticLockException.class, OptimisticLockingFailureException.class})
    public ResponseEntity<ErrorResponse> handleOptimisticLock(Exception ex) {
        log.warn("Optimistic lock conflict: {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(ErrorResponse.builder()
                        .error("CONCURRENT_UPDATE_CONFLICT")
                        .message("This record was modified by another request. " +
                                 "Re-fetch the latest version (GET /api/v2/orders/{id}) " +
                                 "and retry your update with the new 'version' value.")
                        .status(409)
                        .timestamp(LocalDateTime.now())
                        .build());
    }

    // ── Pattern 2: Our explicit version check ────────────────────────────────
    @ExceptionHandler(OptimisticLockConflictException.class)
    public ResponseEntity<ErrorResponse> handleVersionConflict(OptimisticLockConflictException ex) {
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(ErrorResponse.builder()
                        .error("VERSION_CONFLICT")
                        .message(ex.getMessage())
                        .status(409)
                        .timestamp(LocalDateTime.now())
                        .build());
    }

    // ── Pattern 1: Missing idempotency key ───────────────────────────────────
    @ExceptionHandler(MissingIdempotencyKeyException.class)
    public ResponseEntity<ErrorResponse> handleMissingIdempotencyKey(MissingIdempotencyKeyException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ErrorResponse.builder()
                        .error("MISSING_IDEMPOTENCY_KEY")
                        .message(ex.getMessage())
                        .status(400)
                        .timestamp(LocalDateTime.now())
                        .build());
    }

    // ── Validation errors ─────────────────────────────────────────────────────
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidation(MethodArgumentNotValidException ex) {
        String details = ex.getBindingResult().getFieldErrors().stream()
                .map(e -> e.getField() + ": " + e.getDefaultMessage())
                .collect(Collectors.joining("; "));
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ErrorResponse.builder()
                        .error("VALIDATION_FAILED")
                        .message(details)
                        .status(400)
                        .timestamp(LocalDateTime.now())
                        .build());
    }

    // ── Not Found ─────────────────────────────────────────────────────────────
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleNotFound(ResourceNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(ErrorResponse.builder()
                        .error("NOT_FOUND")
                        .message(ex.getMessage())
                        .status(404)
                        .timestamp(LocalDateTime.now())
                        .build());
    }

    // ── Fallback ──────────────────────────────────────────────────────────────
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGeneric(Exception ex) {
        log.error("Unhandled exception", ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(ErrorResponse.builder()
                        .error("INTERNAL_ERROR")
                        .message("An unexpected error occurred. Please try again.")
                        .status(500)
                        .timestamp(LocalDateTime.now())
                        .build());
    }
}
