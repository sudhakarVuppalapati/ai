package com.example.apipatterns.controller;

import com.example.apipatterns.dto.PaymentRequest;
import com.example.apipatterns.dto.PaymentResponse;
import com.example.apipatterns.service.PaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * ═══════════════════════════════════════════════════════════════════════
 * PATTERN 1 DEMO: IDEMPOTENCY KEYS
 * ═══════════════════════════════════════════════════════════════════════
 *
 * Try these scenarios in Postman / curl:
 *
 * SCENARIO A — Normal payment:
 *   POST /api/v2/payments
 *   Headers: Idempotency-Key: my-unique-key-001
 *   → idempotencyResult: "PROCESSED"
 *
 * SCENARIO B — Retry same request (simulate network failure):
 *   POST /api/v2/payments  (same body, same key)
 *   Headers: Idempotency-Key: my-unique-key-001
 *   → idempotencyResult: "REPLAYED" — same result, no double charge ✅
 *
 * SCENARIO C — Missing key:
 *   POST /api/v2/payments  (no Idempotency-Key header)
 *   → 400 Bad Request — "Idempotency-Key header is required"
 * ═══════════════════════════════════════════════════════════════════════
 */
@RestController
@RequestMapping("/api/v2/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    /**
     * Process a payment — safe to retry with the same Idempotency-Key.
     *
     * @param idempotencyKey Client-generated UUID. Must be the same UUID on retries.
     *                       Generate fresh UUID only for new, distinct payment attempts.
     */
    @PostMapping
    public ResponseEntity<PaymentResponse> processPayment(
            @RequestHeader(value = "Idempotency-Key", required = false) String idempotencyKey,
            @Valid @RequestBody PaymentRequest request) {

        PaymentResponse response = paymentService.processPayment(idempotencyKey, request);

        // Return 200 (not 201) because on replay we're not creating a new resource
        HttpStatus status = "PROCESSED".equals(response.idempotencyResult)
                ? HttpStatus.CREATED   // 201 — new payment created
                : HttpStatus.OK;       // 200 — replayed existing result

        return ResponseEntity.status(status).body(response);
    }
}
