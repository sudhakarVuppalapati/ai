package com.example.apipatterns;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Advanced REST API Patterns Demo
 *
 * Demonstrates 4 patterns that separate mid-level from senior API design:
 *
 * 1. IDEMPOTENCY KEYS     → POST /api/v2/payments  (safe retries)
 * 2. OPTIMISTIC LOCKING   → PUT  /api/v2/orders/{id} (safe concurrent updates)
 * 3. GRACEFUL DEPRECATION → GET  /api/v1/orders      (sunset headers + migration path)
 * 4. DOMAIN-DRIVEN DESIGN → GET  /api/v2/users/{id}/orders (business-centric resources)
 */
@SpringBootApplication
public class ApiPatternsApplication {
    public static void main(String[] args) {
        SpringApplication.run(ApiPatternsApplication.class, args);
    }
}
