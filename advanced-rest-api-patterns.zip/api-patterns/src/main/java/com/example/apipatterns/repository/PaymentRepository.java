package com.example.apipatterns.repository;

import com.example.apipatterns.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
    /**
     * Used for idempotency check — find a previous payment by its idempotency key.
     * If found, we return the stored result instead of processing again.
     */
    Optional<Payment> findByIdempotencyKey(String idempotencyKey);
}
