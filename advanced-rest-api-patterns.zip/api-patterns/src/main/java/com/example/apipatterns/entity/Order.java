package com.example.apipatterns.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * PATTERN 2 — OPTIMISTIC LOCKING
 *
 * The @Version field is the key.
 * JPA automatically:
 *   - Includes it in UPDATE WHERE clauses: UPDATE orders SET ... WHERE id=? AND version=?
 *   - Increments it after every successful update
 *   - Throws OptimisticLockException if the version doesn't match (someone else updated first)
 *
 * This means two clients updating simultaneously:
 *   - Client A reads Order{id=1, version=0}
 *   - Client B reads Order{id=1, version=0}
 *   - Client A saves → version becomes 1 ✅
 *   - Client B tries to save with version=0 → JPA throws exception → 409 Conflict ❌
 */
@Entity
@Table(name = "orders")
@Data
@NoArgsConstructor
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;

    private String status;          // PENDING, CONFIRMED, SHIPPED, DELIVERED, CANCELLED

    private BigDecimal totalAmount;

    private String shippingAddress;

    private String notes;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    /**
     * THE OPTIMISTIC LOCK VERSION FIELD
     * JPA tracks this. Every successful write increments it.
     * A stale write (wrong version) throws OptimisticLockException → we return 409.
     */
    @Version
    private Long version;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
