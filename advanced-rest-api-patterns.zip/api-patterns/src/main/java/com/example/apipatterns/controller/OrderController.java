package com.example.apipatterns.controller;

import com.example.apipatterns.dto.*;
import com.example.apipatterns.service.OrderService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * ═══════════════════════════════════════════════════════════════════════
 * ORDER CONTROLLER  —  Patterns 2, 3, and 4
 * ═══════════════════════════════════════════════════════════════════════
 */
@RestController
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;

    // ── Pattern 4: Domain-Driven Design ──────────────────────────────────────
    // URL reflects the business domain: "orders BELONGING TO a user"
    // Compare: /api/orders?userId=5  (DB-centric, mid-level)
    //       vs /api/users/5/orders   (domain-centric, senior) ✅

    /**
     * PATTERN 4 — Get all orders for a user (domain-centric URL)
     *
     * Try:
     *   GET /api/v2/users/1/orders
     *   GET /api/v2/users/1/orders?status=PENDING
     */
    @GetMapping("/api/v2/users/{userId}/orders")
    public ResponseEntity<UserOrdersResponse> getUserOrders(
            @PathVariable Long userId,
            @RequestParam(required = false) String status) {

        return ResponseEntity.ok(orderService.getUserOrders(userId, status));
    }

    /**
     * Create an order
     */
    @PostMapping("/api/v2/orders")
    public ResponseEntity<OrderResponse> createOrder(@Valid @RequestBody OrderRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(orderService.createOrder(request));
    }

    /**
     * Get a single order — note the `version` in the response.
     * Clients must save this and send it back when updating.
     */
    @GetMapping("/api/v2/orders/{orderId}")
    public ResponseEntity<OrderResponse> getOrder(@PathVariable Long orderId) {
        return ResponseEntity.ok(orderService.getOrder(orderId));
    }

    /**
     * ─────────────────────────────────────────────────────────────────────────
     * PATTERN 2: OPTIMISTIC LOCKING — Safe Concurrent Update
     *
     * Workflow:
     *   1. GET  /api/v2/orders/1          → {version: 0, status: "PENDING", ...}
     *   2. PUT  /api/v2/orders/1
     *      Body: {version: 0, status: "CONFIRMED"}
     *
     * Happy path:
     *   → 200 OK  {version: 1, status: "CONFIRMED", ...}
     *
     * Conflict path (someone else updated between your GET and PUT):
     *   → 409 Conflict
     *     {
     *       "error": "VERSION_CONFLICT",
     *       "message": "Order 1 was modified. Re-fetch and retry with version=1."
     *     }
     * ─────────────────────────────────────────────────────────────────────────
     */
    @PutMapping("/api/v2/orders/{orderId}")
    public ResponseEntity<OrderResponse> updateOrder(
            @PathVariable Long orderId,
            @Valid @RequestBody OrderUpdateRequest request) {

        return ResponseEntity.ok(orderService.updateOrder(orderId, request));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PATTERN 3: GRACEFUL DEPRECATION
    //
    // The /api/v1/** endpoints still work but the DeprecationFilter adds:
    //   Deprecation: true
    //   Sunset: Sat, 31 Dec 2025 23:59:59 GMT
    //   Link: <https://api.example.com/api/v2/users/{userId}/orders>; rel="successor-version"
    //   X-Deprecation-Warning: This endpoint is deprecated...
    //
    // The response body is identical — clients aren't broken, just warned.
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * DEPRECATED V1 endpoint — still works, but headers signal migration needed.
     * Try: GET /api/v1/orders?userId=1
     * Check response headers in Postman to see deprecation signals.
     */
    @GetMapping("/api/v1/orders")
    public ResponseEntity<UserOrdersResponse> getOrdersV1(
            @RequestParam Long userId) {
        // Same logic as v2 — just a different URL shape.
        // Deprecation headers are added by DeprecationFilter automatically.
        return ResponseEntity.ok(orderService.getUserOrders(userId, null));
    }

    /**
     * DEPRECATED V1 create — note the flat, action-oriented URL (anti-pattern).
     * Try: POST /api/v1/orders/create
     */
    @PostMapping("/api/v1/orders/create")
    public ResponseEntity<OrderResponse> createOrderV1(@Valid @RequestBody OrderRequest request) {
        // Deprecation headers added by filter
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(orderService.createOrder(request));
    }
}
