package com.example.apipatterns;

import com.example.apipatterns.dto.OrderRequest;
import com.example.apipatterns.dto.OrderUpdateRequest;
import com.example.apipatterns.dto.PaymentRequest;
import com.example.apipatterns.entity.Order;
import com.example.apipatterns.repository.OrderRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.math.BigDecimal;
import java.util.UUID;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.*;

/**
 * Integration tests that demonstrate all 4 patterns.
 * Run with: mvn test
 */
@SpringBootTest
@AutoConfigureMockMvc
class ApiPatternsTests {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;
    @Autowired OrderRepository orderRepository;

    // ─────────────────────────────────────────────────────────────────────────
    // PATTERN 1: IDEMPOTENCY TESTS
    // ─────────────────────────────────────────────────────────────────────────

    @Test
    void pattern1_firstPaymentReturns201AndProcessed() throws Exception {
        String key = UUID.randomUUID().toString();
        PaymentRequest req = PaymentRequest.builder()
                .orderId(1L).userId(1L)
                .amount(new BigDecimal("999.00")).currency("INR").build();

        mockMvc.perform(post("/api/v2/payments")
                .header("Idempotency-Key", key)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.idempotencyResult").value("PROCESSED"))
                .andExpect(jsonPath("$.status").value("SUCCESS"));
    }

    @Test
    void pattern1_retryWithSameKeyReturns200AndReplayed() throws Exception {
        String key = UUID.randomUUID().toString();
        PaymentRequest req = PaymentRequest.builder()
                .orderId(1L).userId(1L)
                .amount(new BigDecimal("500.00")).currency("INR").build();

        // First call
        mockMvc.perform(post("/api/v2/payments")
                .header("Idempotency-Key", key)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.idempotencyResult").value("PROCESSED"));

        // Retry — same key, same body
        mockMvc.perform(post("/api/v2/payments")
                .header("Idempotency-Key", key)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk())                                  // 200, not 201
                .andExpect(jsonPath("$.idempotencyResult").value("REPLAYED")) // ← key assertion
                .andExpect(jsonPath("$.paymentId").isNotEmpty());             // same payment ID
    }

    @Test
    void pattern1_missingKeyReturns400() throws Exception {
        PaymentRequest req = PaymentRequest.builder()
                .orderId(1L).userId(1L)
                .amount(new BigDecimal("100.00")).currency("INR").build();

        mockMvc.perform(post("/api/v2/payments")
                // No Idempotency-Key header
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("MISSING_IDEMPOTENCY_KEY"));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PATTERN 2: OPTIMISTIC LOCKING TESTS
    // ─────────────────────────────────────────────────────────────────────────

    @Test
    void pattern2_updateWithCorrectVersionSucceeds() throws Exception {
        // Step 1: Create an order (version starts at 0)
        OrderRequest createReq = OrderRequest.builder()
                .userId(1L).shippingAddress("Chennai").totalAmount(new BigDecimal("100")).build();

        MvcResult createResult = mockMvc.perform(post("/api/v2/orders")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(createReq)))
                .andExpect(status().isCreated())
                .andReturn();

        String createBody = createResult.getResponse().getContentAsString();
        Long orderId   = objectMapper.readTree(createBody).get("id").asLong();
        Long version   = objectMapper.readTree(createBody).get("version").asLong(); // should be 0

        // Step 2: Update with correct version
        OrderUpdateRequest updateReq = OrderUpdateRequest.builder()
                .version(version).status("CONFIRMED").build();

        mockMvc.perform(put("/api/v2/orders/" + orderId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updateReq)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("CONFIRMED"))
                .andExpect(jsonPath("$.version").value(version + 1)); // version incremented ✅
    }

    @Test
    void pattern2_updateWithStaleVersionReturns409() throws Exception {
        // Step 1: Create order
        OrderRequest createReq = OrderRequest.builder()
                .userId(1L).shippingAddress("Mumbai").totalAmount(new BigDecimal("200")).build();

        MvcResult createResult = mockMvc.perform(post("/api/v2/orders")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(createReq)))
                .andExpect(status().isCreated())
                .andReturn();

        Long orderId = objectMapper.readTree(
                createResult.getResponse().getContentAsString()).get("id").asLong();

        // Step 2: First update (version 0 → 1)
        OrderUpdateRequest firstUpdate = OrderUpdateRequest.builder()
                .version(0L).status("CONFIRMED").build();

        mockMvc.perform(put("/api/v2/orders/" + orderId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(firstUpdate)))
                .andExpect(status().isOk());

        // Step 3: Second update with STALE version (still 0, but DB is now at 1)
        OrderUpdateRequest staleUpdate = OrderUpdateRequest.builder()
                .version(0L)             // ← stale!
                .status("SHIPPED").build();

        mockMvc.perform(put("/api/v2/orders/" + orderId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(staleUpdate)))
                .andExpect(status().isConflict())           // 409 ← key assertion
                .andExpect(jsonPath("$.error").value("VERSION_CONFLICT"))
                .andExpect(jsonPath("$.message", containsString("Re-fetch")));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PATTERN 3: DEPRECATION HEADERS TESTS
    // ─────────────────────────────────────────────────────────────────────────

    @Test
    void pattern3_v1EndpointStillWorksButHasDeprecationHeaders() throws Exception {
        mockMvc.perform(get("/api/v1/orders?userId=1"))
                .andExpect(status().isOk())
                .andExpect(header().string("Deprecation", "true"))             // ← present
                .andExpect(header().string("Sunset", notNullValue()))          // ← present
                .andExpect(header().string("Link", containsString("successor-version")))
                .andExpect(header().string("X-Deprecation-Warning", containsString("deprecated")));
    }

    @Test
    void pattern3_v2EndpointHasNoDeprecationHeaders() throws Exception {
        mockMvc.perform(get("/api/v2/users/1/orders"))
                .andExpect(status().isOk())
                .andExpect(header().doesNotExist("Deprecation"))   // ← absent on v2
                .andExpect(header().doesNotExist("Sunset"));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PATTERN 4: DOMAIN-DRIVEN DESIGN TESTS
    // ─────────────────────────────────────────────────────────────────────────

    @Test
    void pattern4_getUserOrdersReturnsDomainObject() throws Exception {
        mockMvc.perform(get("/api/v2/users/1/orders"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userId").value(1))
                .andExpect(jsonPath("$.userName").isNotEmpty())       // includes user context
                .andExpect(jsonPath("$.orders").isArray())
                .andExpect(jsonPath("$.totalOrders").isNumber());      // aggregated count
    }

    @Test
    void pattern4_filterOrdersByStatus() throws Exception {
        mockMvc.perform(get("/api/v2/users/1/orders?status=PENDING"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.orders[*].status", everyItem(is("PENDING"))));
    }
}
