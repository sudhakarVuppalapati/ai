# Advanced REST API Patterns — Spring Boot Demo

> 4 patterns that separate mid-level API design from production-grade engineering.

---

## Quick Start

```bash
# No Redis needed for basic demo (DB fallback handles idempotency)
mvn spring-boot:run

# With Redis (recommended for Pattern 1):
docker run -d -p 6379:6379 redis
mvn spring-boot:run
```

H2 Console → http://localhost:8080/h2-console  
JDBC URL: `jdbc:h2:mem:apidb`

---

## Pattern 1 — Idempotency Keys (Safe Retries)

**The Problem:** POST /payments fails mid-flight. Client retries → double charge. 💥

**The Fix:** Client generates a UUID once per logical action and sends it as a header.
Server caches the result. Same key on retry = replay cached result, no re-processing.

### How It Works

```
Client                              Server
  │                                   │
  │  POST /api/v2/payments            │
  │  Idempotency-Key: uuid-abc        │
  │ ─────────────────────────────────►│
  │                                   │ Key "uuid-abc" seen before? NO
  │                                   │ → Process payment
  │                                   │ → Store {key: "uuid-abc", result: ...}
  │  201 Created                      │
  │  { idempotencyResult: PROCESSED } │
  │◄─────────────────────────────────│
  │                                   │
  │  [Network timeout — retry!]       │
  │                                   │
  │  POST /api/v2/payments            │
  │  Idempotency-Key: uuid-abc        │  ← same key
  │ ─────────────────────────────────►│
  │                                   │ Key "uuid-abc" seen before? YES
  │                                   │ → Return stored result (no re-processing)
  │  200 OK                           │
  │  { idempotencyResult: REPLAYED }  │  ← client knows it was a replay
  │◄─────────────────────────────────│
```

### curl Examples

```bash
# First call — processes the payment
curl -X POST http://localhost:8080/api/v2/payments \
  -H "Content-Type: application/json" \
  -H "Idempotency-Key: 550e8400-e29b-41d4-a716-446655440001" \
  -d '{"orderId":1,"userId":1,"amount":999.00,"currency":"INR"}'

# Response:
# { "paymentId": 1, "status": "SUCCESS", "idempotencyResult": "PROCESSED", ... }

# Retry with same key — replays, no double charge
curl -X POST http://localhost:8080/api/v2/payments \
  -H "Content-Type: application/json" \
  -H "Idempotency-Key: 550e8400-e29b-41d4-a716-446655440001" \
  -d '{"orderId":1,"userId":1,"amount":999.00,"currency":"INR"}'

# Response:
# { "paymentId": 1, "status": "SUCCESS", "idempotencyResult": "REPLAYED", ... }
#                                                               ^^^^^^^^ key signal

# Missing key — 400 error
curl -X POST http://localhost:8080/api/v2/payments \
  -H "Content-Type: application/json" \
  -d '{"orderId":1,"userId":1,"amount":999.00,"currency":"INR"}'

# Response: 400 Bad Request — MISSING_IDEMPOTENCY_KEY
```

### Key Rules
- Generate a fresh UUID for each **new** payment attempt
- Reuse the same UUID on **retries** of the same payment
- Store the key on the client until you get a definitive success/failure response
- Keys expire after 24–48 hours (TTL in Redis)

---

## Pattern 2 — Optimistic Locking (Safe Concurrent Updates)

**The Problem:** Two users open the same order and both save. Last-write-wins silently
overwrites the first user's changes. Data is lost with no error. 💥

**The Fix:** Every entity has a `version` field. You must prove you've seen the latest
state before writing. Wrong version = 409 Conflict.

### How It Works

```
User A                     Server                     User B
  │                           │                           │
  │  GET /orders/1            │                           │
  │ ─────────────────────────►│                           │
  │  { version: 2, ... }      │  GET /orders/1            │
  │◄─────────────────────────│ ◄─────────────────────────│
  │                           │  { version: 2, ... }      │
  │  [Editing...]             │ ─────────────────────────►│
  │                           │                           │  [Editing...]
  │                           │  PUT /orders/1            │
  │                           │  { version: 2,            │
  │                           │    status: "CONFIRMED" }  │
  │                           │◄─────────────────────────│
  │                           │  UPDATE orders            │
  │                           │  WHERE id=1 AND version=2 │  ← 1 row updated
  │                           │  version now = 3          │
  │                           │  200 OK { version: 3 }   │
  │                           │ ─────────────────────────►│
  │                           │                           │
  │  PUT /orders/1            │                           │
  │  { version: 2,  ← STALE! │                           │
  │    status: "SHIPPED" }    │                           │
  │ ─────────────────────────►│                           │
  │                           │  UPDATE orders            │
  │                           │  WHERE id=1 AND version=2 │  ← 0 rows! version is 3
  │  409 Conflict             │                           │
  │  "Re-fetch and retry"     │                           │
  │◄─────────────────────────│                           │
```

### curl Examples

```bash
# Step 1: Read the order — note the "version" field
curl http://localhost:8080/api/v2/orders/1

# Response:
# { "id": 1, "status": "PENDING", "version": 0, ... }
#                                  ^^^^^^^^^

# Step 2: Update with the version you just read
curl -X PUT http://localhost:8080/api/v2/orders/1 \
  -H "Content-Type: application/json" \
  -d '{"version": 0, "status": "CONFIRMED"}'

# Response:
# { "id": 1, "status": "CONFIRMED", "version": 1, ... }
#                                    ^^^^^^^^^ incremented

# Step 3: Try the same update again (stale version)
curl -X PUT http://localhost:8080/api/v2/orders/1 \
  -H "Content-Type: application/json" \
  -d '{"version": 0, "status": "SHIPPED"}'

# Response: 409 Conflict
# {
#   "error": "VERSION_CONFLICT",
#   "message": "Order 1 was modified since you last fetched it.
#               You sent version=0 but the current version is 1.
#               Re-fetch the order and retry with version=1."
# }
```

### JPA Magic — The @Version Field

```java
@Version
private Long version;
// JPA generates: UPDATE orders SET status=?, version=version+1
//                WHERE id=? AND version=?
//                         ^^^^^^^^^^^^^^^^^^^
// If version doesn't match → OptimisticLockException → 409
```

---

## Pattern 3 — Graceful Deprecation (Evolving Contracts)

**The Problem:** Deleting /v1 endpoints without warning breaks all existing clients overnight. 💥

**The Fix:** Add standard HTTP headers signaling deprecation. Keep the endpoint working.
Clients (and their monitoring tools) can detect and act on the signal.

### Three-Phase Lifecycle

```
Phase 1 — ANNOUNCE (months before removal):
  Response headers added:
    Deprecation: true
    Sunset: Sat, 31 Dec 2025 23:59:59 GMT
    Link: <https://api.example.com/v2/...>; rel="successor-version"
    X-Deprecation-Warning: This endpoint is deprecated...

Phase 2 — WARN (weeks before):
  Same headers + escalate in monitoring alerts

Phase 3 — REMOVE (after sunset date):
  HTTP 410 Gone
  Body: { "error": "ENDPOINT_REMOVED", "migrateTo": "/api/v2/..." }
```

### curl Example

```bash
# Hit a deprecated V1 endpoint — it still works!
curl -i http://localhost:8080/api/v1/orders?userId=1

# Response headers (check these!):
# HTTP/1.1 200 OK
# Deprecation: true
# Sunset: Sat, 31 Dec 2025 23:59:59 GMT
# Link: <https://api.example.com/api/v2/users/{userId}/orders>; rel="successor-version"
# X-Deprecation-Warning: This endpoint is deprecated and will be removed on 2025-12-31.
#                         Please migrate to: /api/v2/users/{userId}/orders
#
# Body: (normal order data — it still works)

# V2 — no deprecation headers
curl -i http://localhost:8080/api/v2/users/1/orders
# No Deprecation header ✅
```

---

## Pattern 4 — Domain-Driven Resource Design

**The Problem:** APIs designed around DB tables, not business concepts.
Clients need multiple calls to get related data. URLs expose internal structure. 💥

**The Fix:** Model URLs and responses around business domains.

### Before vs After

```
❌ Mid-level (DB-centric):
   GET /api/orders?user_id=1&status_id=2
   GET /api/users?id=1   (separate call to get the user's name)

✅ Senior (Domain-centric):
   GET /api/v2/users/1/orders?status=PENDING
   → Returns user info + orders in one domain-coherent response
```

### curl Examples

```bash
# Get all orders for user 1 (domain-centric)
curl http://localhost:8080/api/v2/users/1/orders

# Response:
# {
#   "userId": 1,
#   "userName": "Alice Kumar",      ← user context included
#   "totalOrders": 2,               ← aggregated
#   "orders": [
#     { "id": 1, "status": "PENDING", "totalAmount": 1499.00, "version": 0 },
#     { "id": 2, "status": "CONFIRMED", "totalAmount": 3299.50, "version": 0 }
#   ]
# }

# Filter by status
curl http://localhost:8080/api/v2/users/1/orders?status=PENDING
```

---

## Running Tests

```bash
mvn test
```

Tests cover all 4 patterns including:
- Idempotency: first call vs retry vs missing key
- Optimistic locking: correct version succeeds, stale version → 409
- Deprecation: v1 has headers, v2 doesn't
- Domain design: response structure and status filtering

---

## Project Structure

```
src/main/java/com/example/apipatterns/
├── ApiPatternsApplication.java
├── config/
│   ├── DataLoader.java         # Seeds test data
│   └── RedisConfig.java        # Redis setup (optional)
├── controller/
│   ├── PaymentController.java  # Pattern 1 — Idempotency
│   └── OrderController.java    # Patterns 2, 3, 4
├── dto/
│   └── ApiDTOs.java            # Request/response objects
├── entity/
│   ├── Order.java              # @Version field for Pattern 2
│   ├── Payment.java            # idempotencyKey column
│   └── User.java
├── exception/
│   ├── Exceptions.java         # Custom exceptions
│   └── GlobalExceptionHandler.java
├── filter/
│   └── DeprecationFilter.java  # Pattern 3 — adds headers to /v1/**
├── repository/
│   ├── OrderRepository.java
│   ├── PaymentRepository.java  # findByIdempotencyKey
│   └── UserRepository.java
└── service/
    ├── PaymentService.java     # Pattern 1 logic
    └── OrderService.java       # Patterns 2 & 4 logic
```
